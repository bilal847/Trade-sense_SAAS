import os
from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager
from app.config import Config

# Initialize extensions
db = SQLAlchemy()
migrate = Migrate()
bcrypt = Bcrypt()
jwt = JWTManager()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions with app
    db.init_app(app)
    migrate.init_app(app, db)
    bcrypt.init_app(app)
    jwt.init_app(app)
    
    # Enable CORS
    CORS(app)

    # Register blueprints with correct prefixes
    # Since each blueprint already has its internal prefix (e.g., market_bp has /market),
    # we need to register them under /api/v1 so the final route is /api/v1/market/*
    from app.api.v1.auth_bp import auth_bp as auth_v1_bp
    from app.api.v1.market_bp import market_bp as market_v1_bp
    from app.api.v1.challenge_bp import challenge_bp as challenge_v1_bp
    from app.api.v1.leaderboard_bp import leaderboard_bp as leaderboard_v1_bp
    from app.api.v1.payment_bp import payment_bp as payment_v1_bp
    from app.api.v1.learning_bp import learning_bp as learning_v1_bp
    from app.api.swagger import swagger_bp
    
    # Create new blueprints with the /api/v1 prefix combined with their internal prefixes
    from flask import Blueprint
    
    # Create API version blueprint
    api_v1 = Blueprint('api_v1', __name__, url_prefix='/api/v1')
    
    # Register the individual blueprints within the API version blueprint
    api_v1.register_blueprint(auth_v1_bp)
    api_v1.register_blueprint(market_v1_bp)
    api_v1.register_blueprint(challenge_v1_bp)
    api_v1.register_blueprint(leaderboard_v1_bp)
    api_v1.register_blueprint(payment_v1_bp)
    api_v1.register_blueprint(learning_v1_bp)
    
    # Register the API version blueprint with the main app
    app.register_blueprint(api_v1)
    
    # Register swagger separately
    app.register_blueprint(swagger_bp, url_prefix='/api')

    return app