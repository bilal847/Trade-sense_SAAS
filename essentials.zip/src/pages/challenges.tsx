import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { Challenge } from '@/types';
import { challengeAPI } from '@/services/api';

export default function Challenges() {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchChallenges = async () => {
      try {
        // In a real app, we would call the API
        // const response = await challengeAPI.getChallenges();
        // setChallenges(response.data.challenges);
        
        // For now, using mock data
        const mockChallenges: Challenge[] = [
          {
            id: 1,
            name: "Standard Challenge",
            description: "Start with $10,000 and achieve 10% profit with 5% daily and 10% total max loss",
            start_balance: 10000.00,
            daily_max_loss: 0.05,
            total_max_loss: 0.10,
            profit_target: 0.10,
            max_duration_days: undefined,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          },
          {
            id: 2,
            name: "Advanced Challenge",
            description: "Higher balance with tighter risk controls",
            start_balance: 25000.00,
            daily_max_loss: 0.04,
            total_max_loss: 0.08,
            profit_target: 0.12,
            max_duration_days: 60,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          },
          {
            id: 3,
            name: "Prop Firm Challenge",
            description: "Professional level challenge with strict risk rules",
            start_balance: 50000.00,
            daily_max_loss: 0.03,
            total_max_loss: 0.06,
            profit_target: 0.15,
            max_duration_days: 90,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }
        ];
        
        setChallenges(mockChallenges);
        setLoading(false);
      } catch (err) {
        setError('Failed to load challenges');
        setLoading(false);
      }
    };

    fetchChallenges();
  }, []);

  const startChallenge = async (challengeId: number) => {
    try {
      // In a real app, we would call the API
      // await challengeAPI.startChallenge(challengeId);
      alert(`Starting challenge ${challengeId}. In a real app, this would start the challenge.`);
      // Redirect to dashboard after starting
      window.location.href = '/dashboard';
    } catch (err) {
      alert('Failed to start challenge');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4">Loading challenges...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold text-red-500">Error</h2>
          <p>{error}</p>
          <button 
            className="mt-4 px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
            onClick={() => window.location.reload()}
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Head>
        <title>TradeSense Quant - Challenges</title>
        <meta name="description" content="Prop-firm style trading challenges" />
      </Head>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Trading Challenges</h1>
          <p className="text-gray-400">Take on prop-firm style challenges to prove your trading skills</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((challenge) => (
            <div key={challenge.id} className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-xl font-bold mb-2">{challenge.name}</h2>
              <p className="text-gray-300 mb-4">{challenge.description}</p>
              
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Start Balance:</span>
                  <span className="font-mono">${challenge.start_balance.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Daily Max Loss:</span>
                  <span className="text-red-400">{(challenge.daily_max_loss * 100).toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Total Max Loss:</span>
                  <span className="text-red-400">{(challenge.total_max_loss * 100).toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Profit Target:</span>
                  <span className="text-green-400">{(challenge.profit_target * 100).toFixed(1)}%</span>
                </div>
              </div>
              
              <button
                onClick={() => startChallenge(challenge.id)}
                className="w-full py-2 bg-blue-600 rounded-lg hover:bg-blue-700 font-semibold transition-colors"
              >
                Start Challenge
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}