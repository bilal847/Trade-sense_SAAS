import React from 'react';
import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
      <Head>
        <title>TradeSense Quant - Quantitative Trading Platform</title>
        <meta name="description" content="Professional quantitative trading simulator with multi-asset support" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h1 className="text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">
            TradeSense Quant
          </h1>
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto">
            Professional quantitative trading simulator with multi-asset support. 
            Trade FX, Crypto, and Casablanca stocks with real market data and prop-firm challenges.
          </p>
          
          <div className="flex justify-center space-x-4 mb-16">
            <Link href="/dashboard" className="px-8 py-3 bg-blue-600 rounded-lg hover:bg-blue-700 font-semibold text-lg transition-colors">
              Go to Dashboard
            </Link>
            <Link href="/challenges" className="px-8 py-3 bg-gray-700 rounded-lg hover:bg-gray-600 font-semibold text-lg transition-colors">
              View Challenges
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <h3 className="text-xl font-bold mb-4 text-blue-400">Multi-Asset Trading</h3>
            <p className="text-gray-300">
              Access real-time market data for FX, Crypto, and Casablanca stocks. 
              Trade with institutional-grade data feeds and execution.
            </p>
          </div>
          
          <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <h3 className="text-xl font-bold mb-4 text-green-400">Prop-Firm Challenges</h3>
            <p className="text-gray-300">
              Take on prop firm style challenges with realistic risk management rules. 
              Prove your trading skills to unlock higher limits.
            </p>
          </div>
          
          <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
            <h3 className="text-xl font-bold mb-4 text-purple-400">Quant Analytics</h3>
            <p className="text-gray-300">
              Advanced technical analysis with EMA, RSI, and custom indicators. 
              Make data-driven trading decisions with our quant tools.
            </p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-8 border border-gray-700">
          <h2 className="text-2xl font-bold mb-6 text-center">Real-Time Market Data</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { symbol: 'BTC/USDT', price: '45,231.50', change: '+1.25%' },
              { symbol: 'ETH/USDT', price: '2,845.20', change: '+0.78%' },
              { symbol: 'EUR/USD', price: '1.0852', change: '-0.12%' },
              { symbol: 'IAM', price: '85.10', change: '+0.23%' },
            ].map((item, index) => (
              <div key={index} className="bg-gray-700 p-4 rounded-lg">
                <div className="font-semibold">{item.symbol}</div>
                <div className="text-lg font-mono">{item.price}</div>
                <div className={`text-sm ${item.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                  {item.change}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <footer className="py-8 text-center text-gray-500 border-t border-gray-800">
        <p>TradeSense Quant &copy; {new Date().getFullYear()} - Professional Trading Platform</p>
        <p className="text-sm mt-2">Simulated trading for educational purposes only</p>
      </footer>
    </div>
  );
}