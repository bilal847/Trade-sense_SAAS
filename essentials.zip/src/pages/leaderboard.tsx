import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { LeaderboardEntry } from '@/types';
import { leaderboardAPI } from '@/services/api';

export default function Leaderboard() {
  const [monthlyLeaderboard, setMonthlyLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [allTimeLeaderboard, setAllTimeLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'monthly' | 'alltime'>('monthly');
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().slice(0, 7)); // YYYY-MM format

  useEffect(() => {
    const fetchLeaderboards = async () => {
      try {
        // In a real app, we would call the API
        // const monthlyResponse = await leaderboardAPI.getMonthlyLeaderboard(
        //   parseInt(selectedMonth.split('-')[0]), 
        //   parseInt(selectedMonth.split('-')[1])
        // );
        // setMonthlyLeaderboard(monthlyResponse.data.leaderboard);
        
        // For now, using mock data
        const mockMonthly: LeaderboardEntry[] = [
          {
            user_id: 1,
            user_name: "Alex Trader",
            challenge_id: 1,
            profit_percentage: 0.15,
            equity: 11500,
            status: "PASSED",
            duration: 12,
            created_at: new Date().toISOString()
          },
          {
            user_id: 2,
            user_name: "Sam Investor",
            challenge_id: 1,
            profit_percentage: 0.12,
            equity: 11200,
            status: "PASSED",
            duration: 15,
            created_at: new Date().toISOString()
          },
          {
            user_id: 3,
            user_name: "Jordan Analyst",
            challenge_id: 2,
            profit_percentage: 0.10,
            equity: 11000,
            status: "PASSED",
            duration: 10,
            created_at: new Date().toISOString()
          },
          {
            user_id: 4,
            user_name: "Taylor Quant",
            challenge_id: 1,
            profit_percentage: 0.08,
            equity: 10800,
            status: "IN_PROGRESS",
            duration: 8,
            created_at: new Date().toISOString()
          },
          {
            user_id: 5,
            user_name: "Morgan Trader",
            challenge_id: 1,
            profit_percentage: 0.05,
            equity: 10500,
            status: "IN_PROGRESS",
            duration: 5,
            created_at: new Date().toISOString()
          }
        ];
        
        // For all-time, using mock data
        const mockAllTime: LeaderboardEntry[] = [
          {
            user_id: 1,
            user_name: "Alex Trader",
            challenge_id: 1,
            profit_percentage: 0.25,
            equity: 12500,
            status: "PASSED",
            duration: 20,
            created_at: new Date().toISOString()
          },
          {
            user_id: 6,
            user_name: "Casey Pro",
            challenge_id: 3,
            profit_percentage: 0.22,
            equity: 61000,
            status: "PASSED",
            duration: 25,
            created_at: new Date().toISOString()
          },
          {
            user_id: 2,
            user_name: "Sam Investor",
            challenge_id: 1,
            profit_percentage: 0.18,
            equity: 11800,
            status: "PASSED",
            duration: 18,
            created_at: new Date().toISOString()
          },
          {
            user_id: 7,
            user_name: "Riley Master",
            challenge_id: 2,
            profit_percentage: 0.16,
            equity: 29000,
            status: "PASSED",
            duration: 30,
            created_at: new Date().toISOString()
          },
          {
            user_id: 3,
            user_name: "Jordan Analyst",
            challenge_id: 2,
            profit_percentage: 0.14,
            equity: 28500,
            status: "PASSED",
            duration: 22,
            created_at: new Date().toISOString()
          }
        ];
        
        setMonthlyLeaderboard(mockMonthly);
        setAllTimeLeaderboard(mockAllTime);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching leaderboard:', err);
        setLoading(false);
      }
    };

    fetchLeaderboards();
  }, [selectedMonth]);

  const formatProfit = (profit: number) => {
    return `${(profit * 100).toFixed(2)}%`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4">Loading leaderboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Head>
        <title>TradeSense Quant - Leaderboard</title>
        <meta name="description" content="Top performers on the trading platform" />
      </Head>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Leaderboard</h1>
          <p className="text-gray-400">Top performers in prop-firm challenges</p>
        </div>

        <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
          {/* Tabs */}
          <div className="flex border-b border-gray-700 mb-6">
            <button
              className={`py-2 px-4 font-semibold ${
                activeTab === 'monthly'
                  ? 'text-blue-400 border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('monthly')}
            >
              Monthly
            </button>
            <button
              className={`py-2 px-4 font-semibold ${
                activeTab === 'alltime'
                  ? 'text-blue-400 border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('alltime')}
            >
              All-Time
            </button>
          </div>

          {/* Month selector for monthly tab */}
          {activeTab === 'monthly' && (
            <div className="mb-6">
              <label className="block text-gray-400 mb-2">Select Month</label>
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
              />
            </div>
          )}

          {/* Leaderboard table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="py-3 px-4 text-left">Rank</th>
                  <th className="py-3 px-4 text-left">Trader</th>
                  <th className="py-3 px-4 text-left">Profit %</th>
                  <th className="py-3 px-4 text-left">Equity</th>
                  <th className="py-3 px-4 text-left">Status</th>
                  <th className="py-3 px-4 text-left">Duration (Days)</th>
                </tr>
              </thead>
              <tbody>
                {(activeTab === 'monthly' ? monthlyLeaderboard : allTimeLeaderboard).map((entry, index) => (
                  <tr key={index} className="border-b border-gray-700 hover:bg-gray-750">
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        {index < 3 ? (
                          <span className="w-6 h-6 flex items-center justify-center rounded-full bg-yellow-500/20 text-yellow-400 mr-2">
                            {index + 1}
                          </span>
                        ) : (
                          <span className="w-6 h-6 flex items-center justify-center rounded-full bg-gray-600 mr-2">
                            {index + 1}
                          </span>
                        )}
                        {index === 0 && '🏆'}
                        {index === 1 && '🥈'}
                        {index === 2 && '🥉'}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium">{entry.user_name}</td>
                    <td className={`py-3 px-4 font-mono ${
                      entry.profit_percentage >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {formatProfit(entry.profit_percentage)}
                    </td>
                    <td className="py-3 px-4 font-mono">${entry.equity.toLocaleString()}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded text-xs ${
                        entry.status === 'PASSED' 
                          ? 'bg-green-900/30 text-green-400' 
                          : entry.status === 'FAILED'
                          ? 'bg-red-900/30 text-red-400'
                          : 'bg-yellow-900/30 text-yellow-400'
                      }`}>
                        {entry.status}
                      </span>
                    </td>
                    <td className="py-3 px-4">{entry.duration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}