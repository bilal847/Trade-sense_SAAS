﻿import React, { useState, useEffect } from 'react';
import { Instrument, Quote, OHLCV, Signal, Position, Trade, UserChallenge } from '@/types';
import { marketAPI, challengeAPI } from '@/services/api';
import dynamic from 'next/dynamic';

// Dynamically import TradingView chart to avoid SSR issues
const TVChartContainer = dynamic(() => import('./TVChartContainer'), {
  ssr: false,
  loading: () => <div className="bg-gray-800 p-4 rounded-lg h-96 flex items-center justify-center">Loading chart...</div>
});

// Event type for journal
interface EventLog {
  id: number;
  user_id?: number;
  instrument_id?: number;
  type: string; // 'quote_update', 'signal_change', 'trade_executed', 'risk_evaluation'
  payload_json: any;
  created_at: string;
}

const TradingDashboard: React.FC<{ userChallenge: UserChallenge }> = ({ userChallenge }) => {
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [selectedInstrument, setSelectedInstrument] = useState<Instrument | null>(null);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [ohlcvData, setOhlcvData] = useState<OHLCV[]>([]);
  const [positions, setPositions] = useState<Position[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [signals, setSignals] = useState<Signal[]>([]);
  const [events, setEvents] = useState<EventLog[]>([]);
  const [quantity, setQuantity] = useState<number>(0.1);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState<string>('');
  const [timeframe, setTimeframe] = useState<string>('1h');
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    FX: true,
    CRYPTO: true,
    COMMODITIES: true,
    STOCKS: true
  });

  // Group instruments by asset class
  const groupedInstruments = instruments.reduce((acc, instrument) => {
    const group = instrument.asset_class;
    if (!acc[group]) {
      acc[group] = [];
    }
    acc[group].push(instrument);
    return acc;
  }, {} as Record<string, Instrument[]>);

  // Toggle group expansion
  const toggleGroup = (group: string) => {
    setExpandedGroups(prev => ({
      ...prev,
      [group]: !prev[group]
    }));
  };

  // Fetch instruments
  useEffect(() => {
    const fetchInstruments = async () => {
      try {
        const response = await marketAPI.getInstruments();
        setInstruments(response.data.instruments);
        if (response.data.instruments.length > 0) {
          setSelectedInstrument(response.data.instruments[0]);
        }
      } catch (error) {
        console.error('Error fetching instruments:', error);
      }
    };

    fetchInstruments();
  }, []);

  // Fetch initial data when instrument is selected
  useEffect(() => {
    if (selectedInstrument) {
      fetchChartData();
      fetchQuote();
      fetchSignals();
    }
  }, [selectedInstrument]);

  // Fetch chart data
  const fetchChartData = async () => {
    if (selectedInstrument) {
      try {
        const response = await marketAPI.getOHLCV(selectedInstrument.id, timeframe, 100);
        setOhlcvData(response.data.ohlcv);
      } catch (error) {
        console.error('Error fetching chart data:', error);
      }
    }
  };

  // Fetch quote
  const fetchQuote = async () => {
    if (selectedInstrument) {
      try {
        const response = await marketAPI.getQuote(selectedInstrument.id);
        setQuote(response.data.quote);
        setLastUpdateTime(new Date().toLocaleTimeString());
        
        // Add quote update event to journal
        const newEvent: EventLog = {
          id: Date.now(), // Using timestamp as ID for demo
          instrument_id: selectedInstrument.id,
          type: 'quote_update',
          payload_json: {
            symbol: selectedInstrument.display_symbol,
            bid: response.data.quote.bid,
            ask: response.data.quote.ask,
            last: response.data.quote.last,
            change: ((response.data.quote.last - response.data.quote.bid) / response.data.quote.bid * 100).toFixed(2)
          },
          created_at: new Date().toISOString()
        };
        
        setEvents(prev => [newEvent, ...prev.slice(0, 49)]); // Keep only last 50 events
      } catch (error) {
        console.error('Error fetching quote:', error);
      }
    }
  };

  // Fetch signals
  const fetchSignals = async () => {
    // In a real app, this would come from the backend
    // For now, we'll create mock signals based on current data
    if (selectedInstrument && quote) {
      const mockSignal: Signal = {
        instrument: selectedInstrument.display_symbol,
        direction: Math.random() > 0.5 ? 'LONG' : 'SHORT',
        confidence: Math.random() * 0.5 + 0.5, // Between 50% and 100%
        indicators: {
          rsi: Math.random() * 100,
          ema20: quote.last * (0.95 + Math.random() * 0.1),
          ema50: quote.last * (0.95 + Math.random() * 0.1),
          regime: Math.random() > 0.6 ? 'HIGH' : Math.random() > 0.3 ? 'MED' : 'LOW'
        },
        notes: ['RSI showing bullish divergence', 'Price above both EMAs']
      };
      
      setSignals([mockSignal]);
      
      // Add signal change event to journal
      const newEvent: EventLog = {
        id: Date.now() + 1, // Using timestamp as ID for demo
        instrument_id: selectedInstrument.id,
        type: 'signal_change',
        payload_json: {
          symbol: selectedInstrument.display_symbol,
          direction: mockSignal.direction,
          confidence: mockSignal.confidence,
          regime: mockSignal.indicators.regime
        },
        created_at: new Date().toISOString()
      };
      
      setEvents(prev => [newEvent, ...prev.slice(0, 49)]);
    }
  };

  // Fetch positions and trades
  useEffect(() => {
    if (userChallenge?.id) {
      fetchPositions();
      fetchTrades();
    }
  }, [userChallenge]);

  const fetchPositions = async () => {
    try {
      const response = await challengeAPI.getPositions(userChallenge.id);
      setPositions(response.data.positions);
    } catch (error) {
      console.error('Error fetching positions:', error);
    }
  };

  const fetchTrades = async () => {
    try {
      const response = await challengeAPI.getTrades(userChallenge.id);
      setTrades(response.data.trades);
      
      // Add recent trades to journal
      response.data.trades.slice(0, 5).forEach((trade: Trade) => {
        const instrument = instruments.find(i => i.id === trade.instrument_id);
        const newEvent: EventLog = {
          id: trade.id,
          instrument_id: trade.instrument_id,
          type: 'trade_executed',
          payload_json: {
            symbol: instrument?.display_symbol,
            side: trade.side,
            qty: trade.qty,
            price: trade.price,
            realized_pnl: trade.realized_pnl
          },
          created_at: trade.created_at
        };
        
        setEvents(prev => [...prev, newEvent].sort((a, b) => 
          new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        ).slice(0, 50));
      });
    } catch (error) {
      console.error('Error fetching trades:', error);
    }
  };

  // Fetch events/journal
  useEffect(() => {
    // In a real app, we would fetch from the backend
    // For now, we'll use the events we've created
    const mockEvents: EventLog[] = [
      {
        id: 1,
        instrument_id: 1,
        type: 'risk_evaluation',
        payload_json: {
          status: 'IN_PROGRESS',
          daily_drawdown: 0.02,
          total_drawdown: 0.03,
          distance_to_limit: 0.02
        },
        created_at: new Date(Date.now() - 300000).toISOString() // 5 minutes ago
      },
      {
        id: 2,
        instrument_id: 2,
        type: 'quote_update',
        payload_json: {
          symbol: 'ETH/USDT',
          bid: 2845.20,
          ask: 2846.10,
          last: 2845.50,
          change: '+0.78%'
        },
        created_at: new Date(Date.now() - 600000).toISOString() // 10 minutes ago
      }
    ];
    
    setEvents(mockEvents);
  }, []);

  // Refresh data
  const refreshData = async () => {
    if (selectedInstrument) {
      await fetchQuote();
      await fetchChartData();
      await fetchSignals();
      if (userChallenge?.id) {
        await fetchPositions();
        await fetchTrades();
      }
    }
  };

  // Execute trade
  const executeTrade = async (side: 'BUY' | 'SELL') => {
    if (!selectedInstrument || !userChallenge?.id) return;

    setIsLoading(true);
    try {
      await challengeAPI.executeTrade(userChallenge.id, selectedInstrument.id, side, quantity);
      
      // Add trade executed event to journal
      const newEvent: EventLog = {
        id: Date.now() + 2, // Using timestamp as ID for demo
        instrument_id: selectedInstrument.id,
        type: 'trade_executed',
        payload_json: {
          symbol: selectedInstrument.display_symbol,
          side,
          qty: quantity,
          price: quote?.last || 0,
          status: 'filled'
        },
        created_at: new Date().toISOString()
      };
      
      setEvents(prev => [newEvent, ...prev.slice(0, 49)]);
      
      // Refresh positions and trades after successful trade
      await fetchPositions();
      await fetchTrades();
      // Refresh quote to get latest prices
      await fetchQuote();
    } catch (error) {
      console.error('Error executing trade:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Auto-refresh data every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (selectedInstrument) {
        fetchQuote();
        fetchChartData();
        fetchSignals();
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [selectedInstrument]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 h-full">
      {/* Watchlist Panel with grouped instruments */}
      <div className="lg:col-span-1 bg-gray-800 rounded-lg p-4 h-fit">
        <h3 className="text-lg font-semibold mb-4 text-blue-400">Watchlist</h3>
        
        {/* FX Group */}
        <div className="mb-3">
          <div 
            className="flex justify-between items-center cursor-pointer p-2 bg-gray-700 rounded"
            onClick={() => toggleGroup('FX')}
          >
            <span className="font-medium">FX</span>
            <span>{expandedGroups.FX ? 'â–¼' : 'â–º'}</span>
          </div>
          {expandedGroups.FX && (
            <div className="mt-2 space-y-1 pl-2">
              {groupedInstruments['FX']?.map((instrument) => (
                <div
                  key={instrument.id}
                  className={`p-2 rounded cursor-pointer transition-colors ${
                    selectedInstrument?.id === instrument.id
                      ? 'bg-blue-900 border-l-4 border-blue-500'
                      : 'bg-gray-750 hover:bg-gray-600'
                  }`}
                  onClick={() => setSelectedInstrument(instrument)}
                >
                  <div className="flex justify-between">
                    <span className="font-medium">{instrument.display_symbol}</span>
                    {quote?.ts && (
                      <span className="text-xs">
                        {quote.last.toFixed(4)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Crypto Group */}
        <div className="mb-3">
          <div 
            className="flex justify-between items-center cursor-pointer p-2 bg-gray-700 rounded"
            onClick={() => toggleGroup('CRYPTO')}
          >
            <span className="font-medium">Crypto</span>
            <span>{expandedGroups.CRYPTO ? 'â–¼' : 'â–º'}</span>
          </div>
          {expandedGroups.CRYPTO && (
            <div className="mt-2 space-y-1 pl-2">
              {groupedInstruments['CRYPTO']?.map((instrument) => (
                <div
                  key={instrument.id}
                  className={`p-2 rounded cursor-pointer transition-colors ${
                    selectedInstrument?.id === instrument.id
                      ? 'bg-blue-900 border-l-4 border-blue-500'
                      : 'bg-gray-750 hover:bg-gray-600'
                  }`}
                  onClick={() => setSelectedInstrument(instrument)}
                >
                  <div className="flex justify-between">
                    <span className="font-medium">{instrument.display_symbol}</span>
                    {quote?.ts && (
                      <span className="text-xs">
                        {quote.last.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Commodities Group */}
        <div className="mb-3">
          <div 
            className="flex justify-between items-center cursor-pointer p-2 bg-gray-700 rounded"
            onClick={() => toggleGroup('COMMODITIES')}
          >
            <span className="font-medium">Commodities</span>
            <span>{expandedGroups.COMMODITIES ? 'â–¼' : 'â–º'}</span>
          </div>
          {expandedGroups.COMMODITIES && (
            <div className="mt-2 space-y-1 pl-2">
              {groupedInstruments['COMMODITIES']?.map((instrument) => (
                <div
                  key={instrument.id}
                  className={`p-2 rounded cursor-pointer transition-colors ${
                    selectedInstrument?.id === instrument.id
                      ? 'bg-blue-900 border-l-4 border-blue-500'
                      : 'bg-gray-750 hover:bg-gray-600'
                  }`}
                  onClick={() => setSelectedInstrument(instrument)}
                >
                  <div className="flex justify-between">
                    <span className="font-medium">{instrument.display_symbol}</span>
                    {quote?.ts && (
                      <span className="text-xs">
                        {quote.last.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Stocks (CSE) Group */}
        <div className="mb-3">
          <div 
            className="flex justify-between items-center cursor-pointer p-2 bg-gray-700 rounded"
            onClick={() => toggleGroup('STOCKS')}
          >
            <span className="font-medium">Stocks (CSE)</span>
            <span>{expandedGroups.STOCKS ? 'â–¼' : 'â–º'}</span>
          </div>
          {expandedGroups.STOCKS && (
            <div className="mt-2 space-y-1 pl-2">
              {groupedInstruments['STOCKS']?.map((instrument) => (
                <div
                  key={instrument.id}
                  className={`p-2 rounded cursor-pointer transition-colors ${
                    selectedInstrument?.id === instrument.id
                      ? 'bg-blue-900 border-l-4 border-blue-500'
                      : 'bg-gray-750 hover:bg-gray-600'
                  }`}
                  onClick={() => setSelectedInstrument(instrument)}
                >
                  <div className="flex justify-between">
                    <span className="font-medium">{instrument.display_symbol}</span>
                    {quote?.ts && (
                      <span className="text-xs">
                        {quote.last.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Chart Area */}
      <div className="lg:col-span-2 space-y-4">
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h2 className="text-xl font-bold">
                {selectedInstrument?.display_symbol || 'Select an instrument'}
              </h2>
              {quote && (
                <div className="text-sm text-gray-400">
                  Last: <span className="font-mono">{quote.last.toFixed(2)}</span> | 
                  Bid: <span className="font-mono">{quote.bid.toFixed(2)}</span> | 
                  Ask: <span className="font-mono">{quote.ask.toFixed(2)}</span>
                  <span className="ml-2 text-xs">Last update: {lastUpdateTime}</span>
                </div>
              )}
            </div>
            <div className="flex space-x-2">
              {['1m', '5m', '15m', '1h', '4h', '1d'].map((tf) => (
                <button
                  key={tf}
                  className={`px-3 py-1 rounded text-sm ${
                    timeframe === tf
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                  onClick={() => {
                    setTimeframe(tf);
                    fetchChartData();
                  }}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
          
          <div className="h-96">
            {selectedInstrument ? (
              <TVChartContainer
                symbol={selectedInstrument.display_symbol}
                data={ohlcvData}
                timeframe={timeframe}
              />
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500">
                Select an instrument to view chart
              </div>
            )}
          </div>
        </div>

        {/* Trade Ticket */}
        <div className="bg-gray-800 rounded-lg p-4">
          <h3 className="text-lg font-semibold mb-4 text-green-400">Trade Ticket</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Instrument</label>
              <select
                value={selectedInstrument?.id || ''}
                onChange={(e) => {
                  const instrument = instruments.find(i => i.id === Number(e.target.value));
                  if (instrument) setSelectedInstrument(instrument);
                }}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
              >
                {instruments.map(instrument => (
                  <option key={instrument.id} value={instrument.id}>
                    {instrument.display_symbol}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Quantity</label>
              <input
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white"
                min="0.001"
                step="0.001"
              />
            </div>
            
            <div className="flex space-x-2">
              <button
                onClick={() => executeTrade('BUY')}
                disabled={isLoading}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded font-semibold disabled:opacity-50"
              >
                {isLoading ? 'Processing...' : 'BUY'}
              </button>
              <button
                onClick={() => executeTrade('SELL')}
                disabled={isLoading}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 rounded font-semibold disabled:opacity-50"
              >
                {isLoading ? 'Processing...' : 'SELL'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Signals, Risk, and Journal */}
      <div className="space-y-4">
        {/* Signals Panel */}
        <div className="bg-gray-800 rounded-lg p-4">
          <h3 className="text-lg font-semibold mb-4 text-purple-400">Trading Signals</h3>
          <div className="space-y-3">
            {signals.map((signal, index) => (
              <div
                key={index}
                className={`p-3 rounded border-l-4 ${
                  signal.direction === 'LONG'
                    ? 'border-green-500 bg-green-900/20'
                    : signal.direction === 'SHORT'
                    ? 'border-red-500 bg-red-900/20'
                    : 'border-yellow-500 bg-yellow-900/20'
                }`}
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">{signal.instrument}</span>
                  <span className="text-xs px-2 py-1 rounded bg-gray-700">
                    {Math.round(signal.confidence * 100)}% confidence
                  </span>
                </div>
                <div className="text-sm">
                  <div className="font-semibold">Direction: {signal.direction}</div>
                  <div>RSI: {signal.indicators.rsi?.toFixed(2)}</div>
                  <div>Regime: {signal.indicators.regime}</div>
                </div>
                <div className="mt-2 text-xs text-gray-400">
                  {signal.notes.join(', ')}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Metrics Panel */}
        <div className="bg-gray-800 rounded-lg p-4">
          <h3 className="text-lg font-semibold mb-4 text-orange-400">Risk Metrics</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Account Balance</span>
              <span className="font-mono">${userChallenge.start_balance.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Current Equity</span>
              <span className="font-mono">${userChallenge.current_equity?.toFixed(2) || '0.00'}</span>
            </div>
            <div className="flex justify-between">
              <span>Daily Drawdown</span>
              <span className={`font-mono ${
                (userChallenge.daily_drawdown || 0) > 0.05 ? 'text-red-400' : 'text-green-400'
              }`}>
                {((userChallenge.daily_drawdown || 0) * 100).toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span>Total Drawdown</span>
              <span className={`font-mono ${
                (userChallenge.total_drawdown || 0) > 0.10 ? 'text-red-400' : 'text-green-400'
              }`}>
                {((userChallenge.total_drawdown || 0) * 100).toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span>Profit/Loss</span>
              <span className={`font-mono ${
                (userChallenge.profit_percentage || 0) >= 0 ? 'text-green-400' : 'text-red-400'
              }`}>
                {((userChallenge.profit_percentage || 0) * 100).toFixed(2)}%
              </span>
            </div>
            <div className="pt-2 border-t border-gray-700">
              <div className="text-xs text-gray-400">
                Status: <span className={`font-semibold ${
                  userChallenge.status === 'PASSED' ? 'text-green-400' :
                  userChallenge.status === 'FAILED' ? 'text-red-400' : 'text-yellow-400'
                }`}>
                  {userChallenge.status}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Positions Panel */}
        <div className="bg-gray-800 rounded-lg p-4">
          <h3 className="text-lg font-semibold mb-4 text-cyan-400">Positions</h3>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {positions.length > 0 ? (
              positions.map(position => {
                const instrument = instruments.find(i => i.id === position.instrument_id);
                return (
                  <div key={position.id} className="p-2 bg-gray-700 rounded">
                    <div className="flex justify-between">
                      <span>{instrument?.display_symbol}</span>
                      <span className={position.side === 'LONG' ? 'text-green-400' : 'text-red-400'}>
                        {position.side}
                      </span>
                    </div>
                    <div className="text-sm text-gray-400">
                      Qty: {position.qty} @ ${position.avg_price.toFixed(2)}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="text-gray-500 text-center py-2">No open positions</div>
            )}
          </div>
        </div>

        {/* Journal/Market Feed Panel */}
        <div className="bg-gray-800 rounded-lg p-4 flex flex-col">
          <h3 className="text-lg font-semibold mb-4 text-yellow-400">Market Journal</h3>
          <div className="flex-grow overflow-y-auto max-h-60">
            {events.length > 0 ? (
              <div className="space-y-2">
                {events.map(event => (
                  <div key={event.id} className="p-2 bg-gray-750 rounded text-xs">
                    <div className="flex justify-between">
                      <span className="font-medium">
                        {event.type.replace('_', ' ').toUpperCase()}
                      </span>
                      <span className="text-gray-400">
                        {new Date(event.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className="mt-1 text-gray-300">
                      {event.type === 'quote_update' && (
                        <div>
                          <span>{event.payload_json.symbol}: </span>
                          <span className={parseFloat(event.payload_json.change) >= 0 ? 'text-green-400' : 'text-red-400'}>
                            {event.payload_json.last} ({event.payload_json.change}%)
                          </span>
                        </div>
                      )}
                      {event.type === 'signal_change' && (
                        <div>
                          <span>{event.payload_json.symbol}: </span>
                          <span className={event.payload_json.direction === 'LONG' ? 'text-green-400' : 'text-red-400'}>
                            {event.payload_json.direction} ({Math.round(event.payload_json.confidence * 100)}% conf)
                          </span>
                        </div>
                      )}
                      {event.type === 'trade_executed' && (
                        <div>
                          <span>{event.payload_json.symbol} </span>
                          <span className={event.payload_json.side === 'BUY' ? 'text-green-400' : 'text-red-400'}>
                            {event.payload_json.side}
                          </span>
                          <span> {event.payload_json.qty}@{event.payload_json.price}</span>
                        </div>
                      )}
                      {event.type === 'risk_evaluation' && (
                        <div>
                          <span>DD: {event.payload_json.daily_drawdown * 100}% </span>
                          <span>Tgt: {event.payload_json.distance_to_limit * 100}%</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-gray-500 text-center py-4">No recent activity</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TradingDashboard;
