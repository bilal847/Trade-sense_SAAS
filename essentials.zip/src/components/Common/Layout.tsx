import React from 'react';
import Header from './Header';

interface LayoutProps {
  children: React.ReactNode;
  user?: { email: string } | null;
}

const Layout: React.FC<LayoutProps> = ({ children, user }) => {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Header user={user} />
      <main className="container mx-auto px-4 py-6">
        {children}
      </main>
      <footer className="py-6 text-center text-gray-500 text-sm border-t border-gray-800 mt-12">
        <p>TradeSense Quant &copy; {new Date().getFullYear()} - Professional Trading Platform</p>
        <p className="text-xs mt-2">Simulated trading for educational purposes only</p>
      </footer>
    </div>
  );
};

export default Layout;