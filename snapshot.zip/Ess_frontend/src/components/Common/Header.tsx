import React from 'react';
import Link from 'next/link';

interface HeaderProps {
  user?: { email: string } | null;
}

const Header: React.FC<HeaderProps> = ({ user }) => {
  const handleLogout = () => {
    localStorage.removeItem('access_token');
    window.location.href = '/';
  };

  return (
    <header className="bg-gray-800 border-b border-gray-700">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="text-xl font-bold text-blue-400">
              TradeSense Quant
            </Link>
            <nav className="ml-10 hidden md:flex space-x-8">
              <Link href="/dashboard" className="text-gray-300 hover:text-white">
                Dashboard
              </Link>
              <Link href="/challenges" className="text-gray-300 hover:text-white">
                Challenges
              </Link>
              <Link href="/leaderboard" className="text-gray-300 hover:text-white">
                Leaderboard
              </Link>
              <Link href="/learning" className="text-gray-300 hover:text-white">
                Learning
              </Link>
            </nav>
          </div>
          <div className="flex items-center">
            {user ? (
              <div className="flex items-center space-x-4">
                <span className="text-gray-300 hidden md:block">{user.email}</span>
                <button 
                  onClick={handleLogout}
                  className="px-4 py-2 bg-gray-700 rounded hover:bg-gray-600"
                >
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex space-x-4">
                <Link href="/login" className="px-4 py-2 bg-gray-700 rounded hover:bg-gray-600">
                  Login
                </Link>
                <Link href="/register" className="px-4 py-2 bg-blue-600 rounded hover:bg-blue-700">
                  Register
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;