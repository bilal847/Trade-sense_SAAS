import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { UserChallenge, Instrument, Quote, OHLCV, Signal } from '@/types';
import { challengeAPI, marketAPI } from '@/services/api';
import TradingDashboard from '@/components/Dashboard/TradingDashboard';

export default function Dashboard() {
  const [userChallenge, setUserChallenge] = useState<UserChallenge | null>(null);
  const [activeChallenge, setActiveChallenge] = useState<UserChallenge | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user has an active challenge
  useEffect(() => {
    const fetchActiveChallenge = async () => {
      try {
        setIsLoading(true);
        // In a real app, we would get the user's active challenge
        // For demo, we'll use a mock challenge
        const mockChallenge: UserChallenge = {
          id: 1,
          user_id: 1,
          challenge_id: 1,
          status: 'IN_PROGRESS',
          start_balance: 10000,
          start_time: new Date().toISOString(),
          daily_start_equity: 10000,
          current_equity: 10050.25,
          max_equity: 10100,
          min_equity: 9950,
          min_equity_all_time: 9950,
          min_equity_today: 9980,
          daily_drawdown: 0.005,
          total_drawdown: 0.007,
          profit_percentage: 0.005,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        
        setUserChallenge(mockChallenge);
        setActiveChallenge(mockChallenge);
        setIsLoading(false);
      } catch (err) {
        setError('Failed to load challenge data');
        setIsLoading(false);
      }
    };

    fetchActiveChallenge();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold text-red-500">Error</h2>
          <p>{error}</p>
          <button 
            className="mt-4 px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
            onClick={() => window.location.reload()}
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Head>
        <title>TradeSense Quant - Dashboard</title>
        <meta name="description" content="Professional trading dashboard" />
      </Head>

      <main className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-3xl font-bold">Trading Dashboard</h1>
          <p className="text-gray-400">Real-time trading with multi-asset support</p>
        </div>

        {activeChallenge ? (
          <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-xl font-bold">{activeChallenge.status} Challenge</h2>
                <div className="flex items-center space-x-4 mt-2">
                  <div className="text-sm">
                    <span className="text-gray-400">Balance:</span>{' '}
                    <span className="font-mono">${activeChallenge.start_balance.toFixed(2)}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-400">Equity:</span>{' '}
                    <span className="font-mono">${activeChallenge.current_equity.toFixed(2)}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-400">P&L:</span>{' '}
                    <span className={`font-mono ${
                      (activeChallenge.current_equity - activeChallenge.start_balance) >= 0 
                        ? 'text-green-400' 
                        : 'text-red-400'
                    }`}>
                      ${(activeChallenge.current_equity - activeChallenge.start_balance).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-400">Challenge ID: {activeChallenge.id}</div>
                <div className="text-xs text-gray-500">
                  Started: {new Date(activeChallenge.start_time).toLocaleDateString()}
                </div>
              </div>
            </div>

            <TradingDashboard userChallenge={activeChallenge} />
          </div>
        ) : (
          <div className="bg-gray-800 rounded-xl p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">No Active Challenge</h2>
            <p className="text-gray-400 mb-6">
              You don't have an active trading challenge. Start a challenge to begin trading.
            </p>
            <button 
              className="px-6 py-3 bg-blue-600 rounded-lg hover:bg-blue-700 font-semibold"
              onClick={() => window.location.href = '/challenges'}
            >
              Browse Challenges
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
