import '../styles/globals.css';
import type { AppProps } from 'next/app';
import Layout from '@/components/Common/Layout';

function MyApp({ Component, pageProps }: AppProps) {
  // In a real app, we would get user info from the token
  // For demo, we'll pass a mock user
  const user = { email: 'demo@tradesense.com' };
  
  return (
    <Layout user={user}>
      <Component {...pageProps} />
    </Layout>
  );
}

export default MyApp;