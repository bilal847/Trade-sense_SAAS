import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import { LearningModule, LearningLesson } from '@/types';
import { learningAPI } from '@/services/api';

export default function Learning() {
  const [modules, setModules] = useState<LearningModule[]>([]);
  const [selectedModule, setSelectedModule] = useState<LearningModule | null>(null);
  const [lessons, setLessons] = useState<LearningLesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeLesson, setActiveLesson] = useState<LearningLesson | null>(null);

  useEffect(() => {
    const fetchModules = async () => {
      try {
        // In a real app, we would call the API
        // const response = await learningAPI.getModules();
        // setModules(response.data.modules);
        
        // For now, using mock data
        const mockModules: LearningModule[] = [
          {
            id: 1,
            title: "Risk Management Fundamentals",
            description: "Learn the core principles of trading risk management",
            order: 1,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          },
          {
            id: 2,
            title: "Technical Analysis",
            description: "Master chart patterns, indicators, and technical signals",
            order: 2,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          },
          {
            id: 3,
            title: "Quantitative Strategies",
            description: "Explore algorithmic and quantitative trading approaches",
            order: 3,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          },
          {
            id: 4,
            title: "Position Sizing",
            description: "Optimal position sizing techniques for risk control",
            order: 4,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          },
          {
            id: 5,
            title: "Backtesting Pitfalls",
            description: "Common mistakes in backtesting and how to avoid them",
            order: 5,
            is_active: true,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          }
        ];
        
        setModules(mockModules);
        setSelectedModule(mockModules[0]);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching modules:', err);
        setLoading(false);
      }
    };

    fetchModules();
  }, []);

  useEffect(() => {
    if (selectedModule) {
      // In a real app, we would fetch lessons for the selected module
      const mockLessons: LearningLesson[] = [
        {
          id: 1,
          module_id: selectedModule.id,
          title: "Introduction to Risk Management",
          content: "Risk management is the cornerstone of successful trading. Without proper risk management, even the most profitable strategies can lead to catastrophic losses. This lesson covers the fundamental principles of risk management in trading.",
          order: 1,
          lesson_type: "TEXT",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 2,
          module_id: selectedModule.id,
          title: "Drawdown Control",
          content: "Drawdown control is crucial for long-term trading success. This lesson explains how to calculate and manage drawdowns to protect your capital.",
          order: 2,
          lesson_type: "TEXT",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: 3,
          module_id: selectedModule.id,
          title: "Risk/Reward Ratios",
          content: "Understanding risk/reward ratios is essential for evaluating the potential profitability of trades. This lesson covers how to calculate and use risk/reward ratios effectively.",
          order: 3,
          lesson_type: "QUIZ",
          content_url: "/quizzes/risk-reward",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ];
      
      setLessons(mockLessons);
      setActiveLesson(mockLessons[0]);
    }
  }, [selectedModule]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4">Loading learning content...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Head>
        <title>TradeSense Quant - Learning Hub</title>
        <meta name="description" content="Quantitative trading education" />
      </Head>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Learning Hub</h1>
          <p className="text-gray-400">Master quantitative trading strategies and risk management</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Modules sidebar */}
          <div className="lg:col-span-1 bg-gray-800 rounded-xl p-4 border border-gray-700">
            <h2 className="text-xl font-bold mb-4 text-blue-400">Learning Modules</h2>
            <div className="space-y-2">
              {modules.map(module => (
                <div
                  key={module.id}
                  className={`p-3 rounded cursor-pointer transition-colors ${
                    selectedModule?.id === module.id
                      ? 'bg-blue-900 border-l-4 border-blue-500'
                      : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                  onClick={() => setSelectedModule(module)}
                >
                  <h3 className="font-medium">{module.title}</h3>
                  <p className="text-xs text-gray-400 mt-1">{module.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Lessons and content */}
          <div className="lg:col-span-3 space-y-6">
            {selectedModule && (
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <h2 className="text-2xl font-bold mb-2">{selectedModule.title}</h2>
                <p className="text-gray-400 mb-6">{selectedModule.description}</p>
                
                {/* Lessons list */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold mb-3">Lessons</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {lessons.map(lesson => (
                      <div
                        key={lesson.id}
                        className={`p-3 rounded cursor-pointer transition-colors ${
                          activeLesson?.id === lesson.id
                            ? 'bg-blue-900/50 border border-blue-500'
                            : 'bg-gray-700 hover:bg-gray-600'
                        }`}
                        onClick={() => setActiveLesson(lesson)}
                      >
                        <h4 className="font-medium">{lesson.title}</h4>
                        <div className="flex items-center mt-2">
                          <span className="text-xs px-2 py-1 rounded bg-gray-600">
                            {lesson.lesson_type}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Active lesson content */}
                {activeLesson && (
                  <div className="bg-gray-750 rounded-lg p-6">
                    <h3 className="text-xl font-semibold mb-4">{activeLesson.title}</h3>
                    <div className="prose prose-invert max-w-none">
                      <p>{activeLesson.content}</p>
                      
                      {activeLesson.lesson_type === 'QUIZ' && (
                        <div className="mt-6 p-4 bg-gray-700 rounded-lg">
                          <h4 className="font-semibold mb-3">Knowledge Check</h4>
                          <div className="space-y-3">
                            <div>
                              <p className="mb-2">What is the maximum recommended daily drawdown for a trading account?</p>
                              <div className="space-y-2">
                                {['1%', '2%', '5%', '10%'].map((option, idx) => (
                                  <div key={idx} className="flex items-center">
                                    <input
                                      type="radio"
                                      id={`option-${idx}`}
                                      name="quiz-option"
                                      className="mr-2"
                                    />
                                    <label htmlFor={`option-${idx}`}>{option}</label>
                                  </div>
                                ))}
                              </div>
                            </div>
                            <button className="mt-4 px-4 py-2 bg-blue-600 rounded hover:bg-blue-700">
                              Submit Answer
                            </button>
                          </div>
                        </div>
                      )}
                      
                      {activeLesson.lesson_type === 'LAB' && (
                        <div className="mt-6 p-4 bg-gray-700 rounded-lg">
                          <h4 className="font-semibold mb-3">Quant Lab</h4>
                          <p>In this lab, you'll calculate EMA values for different periods and see how they generate trading signals.</p>
                          <div className="mt-4 p-4 bg-gray-800 rounded">
                            <pre className="text-sm">
                              {`// Example EMA calculation
function calculateEMA(prices, period) {
  const k = 2 / (period + 1);
  let ema = prices[0];
  
  for (let i = 1; i < prices.length; i++) {
    ema = (prices[i] * k) + (ema * (1 - k));
  }
  
  return ema;
}`}
                            </pre>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}